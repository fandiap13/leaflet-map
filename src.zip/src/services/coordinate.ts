import { Feature, ResponseGeoData } from "@/types/PantauMapTypeNew";
import axios from "axios";

export const getCoordinatesAPI = async ({
  q,
  country = "Indonesia",
  details = 1,
  addressType,
}: {
  q: string;
  country?: string;
  details?: number;
  addressType: number;
}) => {
  try {
    const search = q.toLowerCase().trim() == "dki jakarta" ? "Jakarta" : q;
    const { data } = await axios.get(
      "https://nominatim.openstreetmap.org/search",
      {
        params: {
          format: "json",
          q: `${search}, ${country}`,
          addressdetails: details,
        },
      }
    );

    // const query = `
    // [out:json][timeout:25];
    // area["name"="Indonesia"]["admin_level"="2"]->.a;
    // (
    //   relation["admin_level"="4"]["boundary"="administrative"](area.a);
    // );
    // out body;
    // >;
    // out skel qt;
    // `;

    // await fetch("https://overpass-api.de/api/interpreter", {
    //   method: "POST",
    //   body: query,
    // })
    //   .then((res) => res.json())
    //   .then((data) => {
    //     console.log(data); // use osmtogeojson to convert if needed
    //   });

    // console.log({ data });

    // console.log({ data });
    const searchState =
      addressType == 1
        ? "state"
        : addressType == 2
        ? "city"
        : addressType == 3
        ? "city_district"
        : "";

    const responseData =
      searchState == "" || search == "Jakarta" || data.length == 1
        ? data
        : data.filter((item: any) => item.addresstype == searchState);

    // console.log({ responseData });

    return responseData;
  } catch (error) {
    console.error("Error fetching coordinates:", error);
    throw error;
  }
};

const convertOverpassToGeoData = (overpassData: any): ResponseGeoData => {
  const relation = overpassData.elements.find(
    (el: any) => el.type === "relation"
  );
  if (!relation) throw new Error("Relation not found in Overpass response");

  const outerMembers = relation.members.filter(
    (m: any) => m.role === "outer" && m.geometry
  );

  const coordinates = outerMembers.map((member: any) =>
    member.geometry.map((point: any) => [point.lon, point.lat])
  );

  const feature: Feature = {
    type: "Feature",
    geometry: {
      // type: coordinates.length > 1 ? "MultiPolygon" : "Polygon",
      type: coordinates.length > 1 ? "MultiPolygon" : "Polygon",
      coordinates: coordinates.length > 1 ? [coordinates] : [coordinates[0]],
    },
    properties: {
      KODE: relation.id,
      NAME_0: relation.tags?.["name"] || "Unknown",
      NAME_1: relation.tags?.["name"] || "Unknown",
    },
  };

  const responseGeoData: ResponseGeoData = {
    type: "FeatureCollection",
    name: relation.tags?.["name"] || "Unknown",
    features: [feature],
  };

  return responseGeoData;
};

export const getGeoJson = async ({ placeID }: { placeID: string | number }) => {
  try {
    const { data } = await axios.get(
      `https://overpass-api.de/api/interpreter?data=[out:json];relation(${placeID});out%20geom;`
    );

    const geoData = convertOverpassToGeoData(data);

    console.log({ geoData });

    return geoData;
  } catch (error) {
    console.error("Error fetching geojson:", error);
    return null;
  }
};
