// import { ProvinceData } from "@/types/PantauMapType";

// export const populationData: ProvinceData[] = [
//   {
//     province: "Jawa Barat",
//     capital: "Bandung",
//     population: 49189794,
//     males: 24594897,
//     females: 24594897,
//     coordinates: [-6.3178529, 106.6845824],
//     description:
//       "Jawa Barat adalah provinsi dengan jumlah penduduk terpadat di Indonesia, terletak di bagian barat Pulau Jawa.",
//     economicData: {
//       gdp: "Rp 1.841 triliun",
//       mainIndustries: ["Pertanian", "Manufaktur", "Pariwisata"],
//     },
//     socialIndicators: {
//       literacy: "95.3%",
//       poverty: "8.6%",
//       unemployment: "6.5%",
//     },
//   },
//   {
//     province: "Jawa Timur",
//     capital: "Surabaya",
//     population: 39294118,
//     males: 19647059,
//     females: 19647059,
//     coordinates: [-7.2575, 112.7521],
//     description:
//       "Jawa Timur merupakan provinsi terbesar kedua di Pulau Jawa dengan ekonomi yang kuat dan beragam.",
//     economicData: {
//       gdp: "Rp 1.654 triliun",
//       mainIndustries: ["Industri", "Perdagangan", "Perikanan"],
//     },
//     socialIndicators: {
//       literacy: "94.7%",
//       poverty: "10.2%",
//       unemployment: "5.9%",
//     },
//   },
// ];

// export const indonesiaBounds: L.LatLngBoundsExpression = [
//   [-11.0, 94.0], // Barat Daya (Sumatera bagian barat)
//   [6.5, 141.0], // Timur Laut (Papua bagian timur)
// ];

// // const provincePolygons = {
// //     'Jawa Barat': {
// //         type: 'FeatureCollection',
// //         features: [
// //             {
// //                 type: 'Feature',
// //                 properties: { name: 'Jawa Barat' },
// //                 geometry: {
// //                     type: 'Polygon',
// //                     coordinates: [
// //                         [
// //                             [
// //                                 105.45586674424897,
// //                                 -6.778089714556728
// //                             ],
// //                             [
// //                                 105.80426672226332,
// //                                 -6.488167061077164
// //                             ],
// //                             [
// //                                 105.90782701640859,
// //                                 -6.029554565894685
// //                             ],
// //                             [
// //                                 105.99255792933184,
// //                                 -5.926541216643429
// //                             ],
// //                             [
// //                                 108.32762082977081,
// //                                 -6.029549306993758
// //                             ],
// //                             [
// //                                 109.13736038395581,
// //                                 -6.272944636744114
// //                             ],
// //                             [
// //                                 108.77013614999493,
// //                                 -6.927664022791745
// //                             ],
// //                             [
// //                                 108.54413035969333,
// //                                 -7.2173131621129585
// //                             ],
// //                             [
// //                                 108.54414843153967,
// //                                 -7.338729665495038
// //                             ],
// //                             [
// //                                 108.76073230249818,
// //                                 -7.628134577170073
// //                             ],
// //                             [
// //                                 108.61950151822572,
// //                                 -7.889357802547224
// //                             ],
// //                             [
// //                                 105.0510003081871,
// //                                 -7.329402357565698
// //                             ],
// //                             [
// //                                 104.86268878395884,
// //                                 -6.619117997013433
// //                             ],
// //                             [
// //                                 105.04158473197572,
// //                                 -6.469450442045613
// //                             ],
// //                             [
// //                                 105.42762335664537,
// //                                 -6.768740197897998
// //                             ]
// //                         ]
// //                     ]
// //                 }
// //             }
// //         ]
// //     },
// //     // Add more provinces' polygon data
// // };
