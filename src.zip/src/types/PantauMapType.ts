// interface Geometry {
//   // type: "MultiPolygon";
//   type:
//     | "Point"
//     | "MultiPoint"
//     | "LineString"
//     | "MultiLineString"
//     | "Polygon"
//     | "MultiPolygon"
//     | "GeometryCollection"
//     | "Feature"
//     | "FeatureCollection";
//   coordinates: any[];
// }

// interface Properties {
//   KODE: number;
//   NAME_0: string;
//   NAME_1: string;
// }

// interface Feature {
//   type: string;
//   geometry: Geometry;
//   properties: Properties;
// }

// export interface ResponseGeoData {
//   type:
//     | "Point"
//     | "MultiPoint"
//     | "LineString"
//     | "MultiLineString"
//     | "Polygon"
//     | "MultiPolygon"
//     | "GeometryCollection"
//     | "Feature"
//     | "FeatureCollection";
//   name: string;
//   features: Feature[];
// }

// export interface Layanan {
//   nama: string;
//   value: number;
// }

// export interface JenisKelamin {
//   nama: "Laki-laki" | "Perempuan";
//   value: number;
// }

// export interface Pekerjaan {
//   nama: string;
//   value: number;
// }

// export interface Kesimpulan {
//   pekerjaan_terbanyak: string;
//   layanan_terbanyak: string;
//   gender_dominan: "Laki-laki" | "Perempuan";
// }

// export interface Koordinat {
//   lat: number;
//   lng: number;
// }

// export interface Kecamatan {
//   id: number;
//   nama: string;
// }

// export interface Kabupaten {
//   id: number;
//   nama: string;
// }

// export interface Provinsi {
//   id: number;
//   nama: string;
// }

// export interface ProvinceData {
//   id: number;
//   provinsi: Provinsi;
//   // kabupaten: Kabupaten;
//   // kecamatan: Kecamatan;
//   koordinat: Koordinat;
//   total_pemohon: number;
//   layanan: Layanan[];
//   jenis_kelamin: JenisKelamin[];
//   pekerjaan: Pekerjaan[];
//   kesimpulan: Kesimpulan;
// }

// export interface MasterProvinsiData {
//   id: number;
//   nama: string;
//   koordinat?: Koordinat;
// }
// export interface MasterKabupatenData {
//   id: number;
//   nama: string;
//   provinsiId: number;
//   koordinat?: Koordinat;
// }
// export interface MasterKecamatanData {
//   id: number;
//   nama: string;
//   kabupatenId: number;
//   provinsiId: number;
//   koordinat?: Koordinat;
// }
