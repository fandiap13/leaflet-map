// interface Geometry {
//   // type: "MultiPolygon";
//   type:
//     | "Point"
//     | "MultiPoint"
//     | "LineString"
//     | "MultiLineString"
//     | "Polygon"
//     | "MultiPolygon"
//     | "GeometryCollection"
//     | "Feature"
//     | "FeatureCollection";
//   coordinates: any[];
// }

// interface Properties {
//   KODE: number;
//   NAME_0: string;
//   NAME_1: string;
// }

// interface Feature {
//   type: string;
//   geometry: Geometry;
//   properties: Properties;
// }

// export interface ResponseGeoData {
//   type:
//     | "Point"
//     | "MultiPoint"
//     | "LineString"
//     | "MultiLineString"
//     | "Polygon"
//     | "MultiPolygon"
//     | "GeometryCollection"
//     | "Feature"
//     | "FeatureCollection";
//   name: string;
//   features: Feature[];
// }

// export interface ProvinceData {
//   province: string;
//   capital: string;
//   population: number;
//   males: number;
//   females: number;
//   coordinates: [number, number];
//   description: string;
//   economicData: {
//     gdp: string;
//     mainIndustries: string[];
//   };
//   socialIndicators: {
//     literacy: string;
//     poverty: string;
//     unemployment: string;
//   };
// }
