"use client"

import { Button, Label, Select } from 'flowbite-react';
import MapView from './MapView';
import NavbarComponent from '../layout/NavbarComponent';
import { motion } from 'framer-motion';
import { useSidebarContext } from '@/context/SidebarContext';
import { exampleMonitoringData, kabupatenData, kecamatanData, provinsiData } from '@/services/pantauDataNew';
import { useState } from 'react';
import { FilterMap } from '@/types/PantauMapTypeNew';
const geojsonUrl: string = process.env.NEXT_PUBLIC_API_GEO_JSON as string;

const initialFilterData: FilterMap = {
    provinsi: "",
    kab: "",
    kec: "",
};

export default function PantauMap() {
    // const { openSidebar } = useSidebarContext();

    const [filterData, setFilterData] = useState(initialFilterData);

    const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFilterData((prev) => ({
            ...prev,
            [name]: value,
        }));
    };

    return (
        <div className='w-full'>
            <NavbarComponent />

            <div className='w-full h-full lg:h-[calc(100vh-80px)]'>
                <MapView
                    populationData={exampleMonitoringData.data.provinsi}
                    geoUrl={geojsonUrl}
                    filterData={filterData}
                    handleChange={handleChange}
                    setFilterData={setFilterData}
                />
            </div>

            {/* card pencarian */}
            {/* <motion.div
                className="fixed top-[80px] right-0 w-[40%] h-full lg:h-[calc(100vh-80px)] bg-white shadow-lg z-[999] overflow-y-auto border p-4"
                initial={{ width: "40%" }}
                animate={{ x: openSidebar ? 0 : '100%' }} // slide in/out
                transition={{ type: 'tween', duration: 0.3 }}
            >
                <div className='w-full py-4 px-6 rounded-2xl border shadow-sm'>
                    <h3 className='font-semibold text-lg'>Pencarian Wilayah</h3>

                    <div className='grid grid-cols-3 gap-2 mt-2'>
                        <div>
                            <div className="mb-2 block">
                                <Label htmlFor="">Provinsi</Label>
                            </div>
                            <Select name='Provinsi' sizing='sm'>
                                <option>-</option>
                            </Select>
                        </div>
                        <div>
                            <div className="mb-2 block">
                                <Label htmlFor="">Kab/Kota</Label>
                            </div>
                            <Select name='Kab/Kota' sizing='sm'>
                                <option>-</option>
                            </Select>
                        </div>
                        <div>
                            <div className="mb-2 block">
                                <Label htmlFor="">Kecamatan</Label>
                            </div>
                            <Select name='Kecamatan' sizing='sm'>
                                <option>-</option>
                            </Select>
                        </div>
                    </div>

                    <div className='mt-4'>
                        <Button color='dark' size='sm' fullSized className='rounded-full'>Tampilkan</Button>
                    </div>
                </div>
            </motion.div> */}
        </div>
    );
}

