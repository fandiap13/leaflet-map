// import dynamic from 'next/dynamic';
// import React, { useEffect, useState } from 'react'
// // import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
// import 'leaflet/dist/leaflet.css';
// import "leaflet-defaulticon-compatibility"
// import "leaflet-defaulticon-compatibility/dist/leaflet-defaulticon-compatibility.css"
// import "leaflet.fullscreen";
// import "leaflet.fullscreen/Control.FullScreen.css"; // Pastikan CSS diimport
// import FullscreenControlComponent from './FullScreenControlComponent';
// import axios from 'axios';
// import LoadingComponentNew from '../LoadingComponentNew';
// import { Button, Label, Modal, Select } from 'flowbite-react';
// import { LocationBase, ResponseGeoData } from '@/types/PantauMapTypeNew';
// import { indonesiaBounds, kabupatenData, kecamatanData, provinsiData } from '@/services/pantauDataNew';
// import { getCoordinatesAPI, getGeoJson } from '@/services/coordinate';
// import { CoordinatePlace } from '@/types/coordinateType';
// import Swal from 'sweetalert2';
// // import L from 'leaflet';

// const MapContainer = dynamic(() => import("react-leaflet").then((mod) => ({ default: mod.MapContainer })), { ssr: false });
// const TileLayer = dynamic(() => import("react-leaflet").then((mod) => ({ default: mod.TileLayer })), { ssr: false });
// const Marker = dynamic(() => import("react-leaflet").then((mod) => ({ default: mod.Marker })), { ssr: false });
// const Popup = dynamic(() => import("react-leaflet").then((mod) => ({ default: mod.Popup })), { ssr: false });
// const GeoJSON = dynamic(() => import('react-leaflet').then((mod) => mod.GeoJSON), { ssr: false });

// // Ensure Leaflet is only loaded in the browser
// const isBrowser = typeof window !== "undefined";
// const L = isBrowser ? require("leaflet") : null;

// interface MapViewProps {
//     geoUrl: string;
//     populationData: LocationBase[],
// }

// interface GeoJsonPropsStyle {
//     color?: string,
//     weight?: number,
//     fillOpacity?: number,
//     // fillColor?: string,
// }

// const MapView: React.FC<MapViewProps> = ({ geoUrl, populationData }) => {
//     const [customIcon, setCustomIcon] = useState<L.Icon>(
//         new L.Icon({
//             iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
//             iconSize: [25, 41],
//             iconAnchor: [12, 41]
//         })
//     );

//     const [mapKey, setMapKey] = useState(0);

//     const [geoJsonStyle, setGeoJsonStyle] = useState<GeoJsonPropsStyle>({
//         color: "rgba(255, 0, 0)",
//         weight: 2,
//         fillOpacity: 0,
//     });

//     const [dataMap, setDataMap] = useState<LocationBase[]>(populationData);
//     const [loadingGet, setLoadingGet] = useState(false);
//     const [geoData, setGeoData] = useState<ResponseGeoData | null>(null);

//     const [selectedProvince, setSelectedProvince] = useState<LocationBase | null>(null);
//     const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

//     const [isNotDisabledZoom, setisNotDisabledZoom] = useState(true);
//     const [maxBounds, setMaxBounds] = useState<L.LatLngBoundsExpression>(indonesiaBounds);
//     const [centerPosition, setCenterPosition] = useState<[number, number]>(dataMap.length > 0 ? [dataMap[0].lat, dataMap[0].long] : [-2.8, 120]);
//     const [zoom, setZoom] = useState<number>(5);
//     const [minZoom, setMinZoom] = useState<number>(5)
//     const [statusMap, setStatusMap] = useState<number>(dataMap.length > 0 && dataMap[0].status ? dataMap[0].status : 1);

//     const reloadMap = () => {
//         setMapKey(prev => prev + 1);
//     };

//     const getGeoData = async () => {
//         await axios.get(geoUrl)
//             .then((response) => {
//                 const responseGeo: ResponseGeoData | null = response.data;
//                 if (responseGeo) {
//                     setGeoData(response.data);
//                 }
//             })
//             .catch((error) => console.error("Error loading GeoJSON:", error))
//             .finally(() => {
//                 reloadMap();
//                 setLoadingGet(false)
//             });
//     }

//     const handleMarkerClick = async (location: LocationBase) => {
//         setSelectedProvince(location);
//         setIsModalOpen(true);
//     }

//     const handleSearchLocation = async (location: LocationBase, statusMap: number) => {
//         if (statusMap >= 3) {
//             return;
//         }

//         try {
//             setLoadingGet(true);
//             const data = await getCoordinatesAPI({ q: location.nama });
//             // console.log(response);
//             if (data.length > 0) {
//                 const response: CoordinatePlace = data[0];

//                 // buat geo baru
//                 const dataGeoJson = await getGeoJson({ placeID: response.osm_id });
//                 // console.log({ dataGeoJson });
//                 // const name = dataGeoJson.features[0]?.properties?.name || "Unknown Area";
//                 // const formattedGeoData: ResponseGeoData = {
//                 //     ...dataGeoJson,
//                 //     name,
//                 // };

//                 setGeoData(dataGeoJson);
//                 setCenterPosition([parseFloat(response.lat), parseFloat(response.lon)])
//                 // setMaxBounds([
//                 //     [parseFloat(response.boundingbox[0]), parseFloat(response.boundingbox[1])],
//                 //     [parseFloat(response.boundingbox[2]), parseFloat(response.boundingbox[3])]
//                 // ]);

//                 if (statusMap == 1) {
//                     setZoom(7);
//                     setMinZoom(7);

//                     const kabData = populationData.find((prov) => prov.id === location.id);
//                     if (kabData?.kabupaten && kabData.kabupaten.length > 0) {
//                         setDataMap(kabData.kabupaten);
//                         console.log({ kabData: kabData?.kabupaten });
//                     }

//                     setGeoJsonStyle(prev => ({
//                         ...prev,
//                         // fillColor: "rgba(0, 128, 0, 0.4)",
//                         fillOpacity: 1,
//                         color: "rgba(0, 128, 0)",
//                     }));

//                     setCustomIcon(prev =>
//                         new L.Icon({
//                             ...prev.options,
//                             iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
//                         })
//                     );

//                 }

//                 if (statusMap == 2) {
//                     setZoom(10);
//                     setMinZoom(7);

//                     const kecData = dataMap.find((kab) => kab.id === location.id);
//                     if (kecData?.kecamatan && kecData.kecamatan.length > 0) {
//                         setDataMap(kecData.kecamatan);
//                         console.log({ kecData: kecData?.kecamatan });
//                     }

//                     setGeoJsonStyle(prev => ({
//                         ...prev,
//                         // fillColor: "rgba(0, 128, 0, 0.4)",
//                         fillOpacity: 1,
//                         color: "rgba(243,161,41)"
//                     }));

//                     setCustomIcon(prev =>
//                         new L.Icon({
//                             ...prev.options,
//                             iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
//                         })
//                     );

//                 }

//                 setisNotDisabledZoom(false);
//                 setStatusMap(statusMap + 1);
//             } else {
//                 Swal.fire({
//                     title: "Peringatan!",
//                     text: "Data lokasi tidak ditemukan!",
//                     icon: "error"
//                 });
//             }
//             reloadMap();
//         } catch (error: any) {
//             Swal.fire({
//                 title: "Error!",
//                 text: error.message || "Data lokasi tidak ditemukan!",
//                 icon: "error"
//             });
//             reloadMap();
//         } finally {
//             setLoadingGet(false);
//             reloadMap();
//         }
//     };

//     const handleSubmitFilterData = (e:any) => {
//         e.preventDefault();
//         // handleSearchLocation({})
//     }

//     const closeModal = () => {
//         setIsModalOpen(false);
//         setSelectedProvince(null);
//     };

//     // const [selectedFeature, setSelectedFeature] = useState<number | null>(null);

//     // const handleFeatureClick = (feature: any) => {
//     //     console.log({ feature })
//     //     setSelectedFeature((prev) => (prev === feature.properties.KODE ? null : feature.properties.KODE));
//     // };

//     useEffect(() => {
//         setLoadingGet(true);
//         getGeoData();
//     }, []);

//     return (
//         <div className='w-full flex'>
//             <div className='w-3/4'>
//                 <MapContainer
//                     key={mapKey}
//                     center={centerPosition}
//                     zoom={zoom}
//                     minZoom={minZoom}
//                     maxBounds={maxBounds}
//                     maxBoundsViscosity={1.0}
//                     className='w-full h-full'
//                 // scrollWheelZoom={isNotDisabledZoom}
//                 // doubleClickZoom={isNotDisabledZoom}
//                 // boxZoom={isNotDisabledZoom}
//                 // touchZoom={isNotDisabledZoom}
//                 // keyboard={isNotDisabledZoom}
//                 >
//                     <TileLayer
//                         url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
//                         attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
//                     />

//                     {/* Tambahkan FullscreenControl */}
//                     <FullscreenControlComponent />

//                     {/* {Object.entries(provincePolygons).map(([provinceName, geoJSON]) => (
//                                     <GeoJSON
//                                         key={provinceName}
//                                         data={geoJSON}
//                                         style={geoJSONStyle}
//                                         onEachFeature={onEachFeature}
//                                     />
//                                 ))} */}

//                     {geoData && (
//                         <GeoJSON
//                             data={geoData}
//                             style={geoJsonStyle}
//                         // onEachFeature={(feature, layer) => {
//                         //     // if (feature.properties && feature.properties.Propinsi) {
//                         //     //     layer.bindPopup(`<b>Provinsi:</b> ${feature.properties.Propinsi}`);
//                         //     // }
//                         //     layer.on("click", () => handleFeatureClick(feature));
//                         // }}
//                         />
//                     )}

//                     {dataMap.map((province, index) => (
//                         <Marker
//                             key={index}
//                             position={[province.lat, province.long] as L.LatLngTuple}
//                             icon={customIcon}
//                             eventHandlers={{
//                                 click: () => handleMarkerClick(province)
//                             }}
//                         >
//                             {/* <Popup>
//                             <div>
//                                 <h3 className="font-bold text-lg">{province.nama}</h3>
//                                 <p>Total Penduduk: {province.total_pemohon.toLocaleString()} jiwa</p>
//                             </div>
//                         </Popup> */}
//                         </Marker>
//                     ))}
//                 </MapContainer>
//             </div>

//             <div className="w-1/4 h-auto lg:h-[calc(100vh-80px)] bg-white  border p-4">
//                 <h3 className='font-semibold text-lg'>Pencarian Wilayah</h3>

//                 <div className='flex flex-col gap-2 mt-2'>
//                     <div>
//                         <div className="mb-2 block">
//                             <Label htmlFor="provinsi">Provinsi</Label>
//                         </div>
//                         <Select name='provinsi' id='provinsi'>
//                             <option value={""}>-- pilh --</option>
//                             {provinsiData.map((prov) => (
//                                 <option value={prov.id}>{prov.nama}</option>
//                             ))}
//                         </Select>
//                     </div>
//                     <div>
//                         <div className="mb-2 block">
//                             <Label htmlFor="kab">Kab/Kota</Label>
//                         </div>
//                         <Select name='kab' id='kab'>
//                             <option value={""}>-- pilh --</option>
//                             {kabupatenData.map((kab) => (
//                                 <option value={kab.id}>{kab.nama}</option>
//                             ))}
//                         </Select>
//                     </div>
//                     <div>
//                         <div className="mb-2 block">
//                             <Label htmlFor="kec">Kecamatan</Label>
//                         </div>
//                         <Select name='kec' id='kec'>
//                             <option value={""}>-- pilh --</option>
//                             {kecamatanData.map((kec) => (
//                                 <option value={kec.id}>{kec.nama}</option>
//                             ))}
//                         </Select>
//                     </div>
//                 </div>

//                 <div className='mt-4'>
//                     <Button color='warning' fullSized className='rounded !text-lg'>Tampilkan</Button>

//                     <Button
//                         color='dark'
//                         onClick={getGeoData}
//                         className='w-full mt-2 bg-dark/80 text-white hover:bg-dark/70 rounded'>
//                         Atur Ulang
//                     </Button>
//                 </div>
//             </div>


//             {/* Modal Detail Provinsi */}
//             {selectedProvince && (
//                 <Modal show={isModalOpen} onClose={closeModal} size="4xl" style={{ zIndex: "9999" }}>
//                     <Modal.Header className="">{selectedProvince.nama}</Modal.Header>
//                     <Modal.Body className="space-y-6 bg-white">
//                         <div>
//                             <h3 className="text-lg font-semibold">Jumlah Penduduk</h3>
//                             <p>Total: {selectedProvince.jumlahPenduduk.total.toLocaleString()}</p>
//                             <p>
//                                 Perbandingan Tahun Sebelumnya: {selectedProvince.jumlahPenduduk.perbandinganTahunSebelumnya.persentase}% (
//                                 {selectedProvince.jumlahPenduduk.perbandinganTahunSebelumnya.status})
//                             </p>
//                         </div>

//                         <div>
//                             <h3 className="text-lg font-semibold">Berdasarkan Gender</h3>
//                             <ul className="list-disc ml-5">
//                                 <li>Laki-laki: {selectedProvince.jumlahPenduduk.berdasarkanGender.lakiLaki.toLocaleString()}</li>
//                                 <li>Perempuan: {selectedProvince.jumlahPenduduk.berdasarkanGender.perempuan.toLocaleString()}</li>
//                             </ul>
//                         </div>

//                         <div>
//                             <h3 className="text-lg font-semibold">Kelompok Usia</h3>
//                             <ul className="list-disc ml-5">
//                                 {selectedProvince.jumlahPenduduk.berdasarkanKelompokUsia.map((item: any) => (
//                                     <li key={item.kelompok}>
//                                         {item.kelompok}: {item.jumlah.toLocaleString()}
//                                     </li>
//                                 ))}
//                             </ul>
//                         </div>

//                         <div>
//                             <h3 className="text-lg font-semibold">Pekerjaan</h3>
//                             <ul className="list-disc ml-5">
//                                 {selectedProvince.jumlahPenduduk.berdasarkanPekerjaan.map((item: any) => (
//                                     <li key={item.pekerjaan}>
//                                         {item.pekerjaan}: {item.jumlah.toLocaleString()}
//                                     </li>
//                                 ))}
//                             </ul>
//                         </div>

//                         <div>
//                             <h3 className="text-lg font-semibold">Total Pemohon: {selectedProvince.totalPemohon.toLocaleString()}</h3>
//                         </div>

//                         <div>
//                             <h3 className="text-lg font-semibold">Kesimpulan</h3>
//                             <ul className="list-disc ml-5">
//                                 <li>Pekerjaan Terbanyak: {selectedProvince.kesimpulan.pekerjaanTerbanyak.nama} ({selectedProvince.kesimpulan.pekerjaanTerbanyak.jumlah})</li>
//                                 <li>Pekerjaan Tersedikit: {selectedProvince.kesimpulan.pekerjaanTersedikit.nama} ({selectedProvince.kesimpulan.pekerjaanTersedikit.jumlah})</li>
//                                 <li>Usia Terbanyak: {selectedProvince.kesimpulan.kelompokUsiaTerbanyak.nama} ({selectedProvince.kesimpulan.kelompokUsiaTerbanyak.jumlah})</li>
//                                 <li>Usia Tersedikit: {selectedProvince.kesimpulan.kelompokUsiaTersedikit.nama} ({selectedProvince.kesimpulan.kelompokUsiaTersedikit.jumlah})</li>
//                                 <li>Gender Dominan: {selectedProvince.kesimpulan.genderDominan.nama} ({selectedProvince.kesimpulan.genderDominan.jumlah} orang, {selectedProvince.kesimpulan.genderDominan.persentase}%)</li>
//                                 <li>Layanan Terbanyak: {selectedProvince.kesimpulan.rekapLayananTerbanyak.nama} ({selectedProvince.kesimpulan.rekapLayananTerbanyak.jumlah})</li>
//                                 <li>Layanan Tersedikit: {selectedProvince.kesimpulan.rekapLayananTersedikit.nama} ({selectedProvince.kesimpulan.rekapLayananTersedikit.jumlah})</li>
//                             </ul>
//                         </div>
//                     </Modal.Body>
//                 </Modal>
//             )}

//             <LoadingComponentNew loading={loadingGet} />
//         </div>
//     )
// }

// export default MapView